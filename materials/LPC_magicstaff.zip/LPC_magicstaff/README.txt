Magic staff, based on one of LordNeo's staves at https://opengameart.org/content/staff-64-x64.
Can be used with or without magic charge. I plan to use as a projectile launcher (with the nonmagic frame used for when its "empty") but it could easily work as a melee attack as well. Available for male and female.

Public Domain CC0, but I kindly request (without any obligation) that you credit LordNeo and I.